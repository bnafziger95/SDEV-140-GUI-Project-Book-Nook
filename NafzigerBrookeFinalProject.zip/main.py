# final GUI project: Book Nook: main window
# author: Brooke Nafziger
# created: 2025-05-10
# NO CODING ASSISTANCE was used in this program


# main window

# import libraries: tkinter, json
# import custom modules: add_book, view_library, utils
# window title: "Book Nook"
# welcome image
# add book button --> opens add book window
# view library button --> opens view library window
# exit button --> closes program
# define functions:
# main() --> set up main window
# open_add_book_window() --> calls function from add_book.py
# open_view_books_window() --> calls function from view_library.py
# exit_program() --> closes program


# start of main.py
# import libraries
import tkinter as tk
from tkinter import messagebox   # for message boxes

import json
import os
from PIL import ImageTk, Image

# import custom modules
from add_book import open_add_book_window  # function to open add book window
from view_library import open_view_books_window  # function to open view library window
#from utils import load_library, save_library  # functions to load and save library data

# define exit program function
def exit_program():
    """closes program"""
    if messagebox.askokcancel("Exit", "Are you sure you want to exit?"):  # ask for confirmation
        #root.destroy()  # destroy main window
        exit()
    else:
        pass

# main window
root = tk.Tk()
root.title("Book Nook")  # set title
root.geometry("700x600")   # set window size
root.configure(bg="#CCCCFF")  # set background color
root.resizable(False, False)  # prevent resizing

# show a title label
title_label = tk.Label(root, text="Welcome to Book Nook", bg="#CCCCFF", fg="grey", font=("Segoe Script", 24))  # title label
title_label.pack(pady=20)  # add padding

# image for main window
original_img = Image.open("main_book_image.jpg")
resize_img = original_img.resize((250, 250), Image.LANCZOS)  # resize image and high quality with LANCZOS
img = ImageTk.PhotoImage(resize_img)

# create panel and pack it
panel = tk.Label(root, image = img)
panel.image = img   # keep a reference to aboid garbage collection
panel.pack(pady=10)

# format buttons
add_book_button = tk.Button(root, text="Add Book", command = open_add_book_window, bg = "#8A2BE2", fg = "white", font = ("Arial", 12), width = 20, height = 2)  # button to add book
add_book_button.pack(pady=10)   # add padding

view_library_button = tk.Button(root, text = "View Library",command = open_view_books_window, bg = "#FFDBBB", fg = "black", font = ("Arial", 12), width = 12, height = 2) # button to view library
view_library_button.pack(pady=10)   # add padding

exit_button = tk.Button(root, text = "Exit", command = exit_program, bg = "black", fg = "white", font = ("Arial", 12), width = 12, height = 2)   # button to exit program
exit_button.pack(pady=10)  # add padding

# runs main window
root.mainloop()

