# utility functions for project NO WINDOW

# import json
# define functions:
# load_library() --> loads library.json and returns data
# save_library(data) --> saves data to library.json
# validate_input(title, author, genre, rating, status) --> validates input fields


# import json
import json

# define functions
def load_library(file_path='library.json'):
    """loads library.json and returns data"""
    try:
        with open(file_path, 'r') as file:
            data = json.load(file)
        return data
    except FileNotFoundError:
        return []  # return empty list if file not found
    except json.JSONDecodeError:
        return []  # return empty list if JSON is invalid

def save_library(data, file_path='library.json'):
    """saves data to library.json"""
    with open(file_path, 'w') as file:   # open file in write mode
        json.dump(data, file, indent=4)  # save data in JSON format with indentation
    return True  # return True if save is successful

# define json file path
def get_json_file_path():
    """returns json file path"""
    return 'library.json'  # return json file path
