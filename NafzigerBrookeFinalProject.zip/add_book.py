# add books window

# import libraries: tkinter, json
# window title: "Add Book"
# labels: "Title", "Author", "Genre" (dropdown), "Rating" (1-5), Status (Want to Read, Currently Reading, Finished)
# entry fields for title, author, rating
# drop down for genre: "Fiction", "Non-Fiction", "Romance", "Sci-Fi", "Fantasy", "Other"
# button: "Add Book" --> adds book to library.json
# button: "Back to Main" --> closes add book window and returns to main window
# functions:
# open_add_book_window() --> creates add book window
# submit_book() --> adds book to library.json, validate input, show success/error message
# clear_fields() --> clears input fields after submission
# back_to_main() --> closes add book window and returns to main window


# start of add_book.py
# import libraries
import tkinter as tk
from tkinter import messagebox, ttk  # for message boxes and dropdowns
from PIL import ImageTk, Image  # for image handling
import json

# import utility functions from util.py
from utils import load_library, save_library

# define genre options, status options, and rating options
def get_genre_options():
    """returns genre options"""
    return ["Fiction", "Non-Fiction", "Romance", "Sci-Fi", "Fantasy", "Other"]  # list of genre options

def get_status_options():
    """returns status options"""
    return ["Want to Read", "Currently Reading", "Finished"]  # list of status options

def get_rating_options():
    """returns rating options"""
    return [1, 2, 3, 4, 5, "No Rating"]  # list of rating options

def clear_fields(title_entry, author_entry, genre_dropdown, rating_dropdown, status_dropdown):
    """clears input fields after submission"""
    title_entry.delete(0, tk.END)  # clear title entry field
    author_entry.delete(0, tk.END)  # clear author entry field
    genre_dropdown.set("")  # clear genre dropdown
    rating_dropdown.set("")  # clear rating dropdown
    status_dropdown.set("")  # clear status dropdown

#def back_to_main():
    #"""closes add book window and returns to main window"""
    #add_book_window.destroy()  # destroy the add book window
    # main_window.deiconify()  # show the main window (if needed)

def show_message(title, message):
    """shows message box"""
    messagebox.showinfo(title, message)  # show message box with title and message

def load_library(file_path = 'library.json'):
    """loads library.json and returns data"""
    try:
        with open(file_path, 'r') as file:  # open file in read mode
            data = json.load(file)  # load JSON data
            return data  # return data
    except FileNotFoundError:
        return []   # return empty list if file not found
    except json.JSONDecodeError:
        return []  # return empty list if JSON is invalid

def save_library(data, file_path = 'library.json'):
    """saves data to library.json"""
    with open(file_path, 'w') as file:  # open file in write mode
        json.dump(data, file, indent=4)  # save data in JSON format with indentation
    return True  # return True if save is successful


# create add book window
def open_add_book_window():
    # create add book window
    add_book_window = tk.Toplevel()  # create a new window
    add_book_window.title("Add Book")  # set title
    add_book_window.geometry("500x800")  # set window size
    add_book_window.configure(bg = "#E6E6FA")  # set background color
    add_book_window.resizable(False, False)  # prevent resizing

    # show image in add book window
    original_img = Image.open("bookshelf_image.png")
    resize_img = original_img.resize((200, 200), Image.LANCZOS)  # resize image and high quality with LANCZOS
    img = ImageTk.PhotoImage(resize_img)

    # create panel and pack it
    panel = tk.Label(add_book_window, image = img, bg="lavender")  # create label for image
    panel.image = img   # keep a reference to aboid garbage collection
    panel.pack(pady=10)

    # create labels and entry fields
    title_label = tk.Label(add_book_window, text="Title:", bg = "lavender", fg = "black", font = ("Arial", 12))  # label for title 
    title_label.pack(pady=5)  # add padding

    title_entry = tk.Entry(add_book_window, width=30)  # entry field for title
    title_entry.pack(pady=5) # add padding

    author_label = tk.Label(add_book_window, text="Author:", bg = "lavender", fg = "black", font = ("Arial", 12))  # label for author
    author_label.pack(pady=5)  # add padding

    author_entry = tk.Entry(add_book_window, width=30)  # entry field for author
    author_entry.pack(pady=5)  # add padding

    # genre label and dropdown
    genre_label = tk.Label(add_book_window, text="Genre:", bg = "lavender", fg = "black", font = ("Arial", 12))  # label for genre
    genre_label.pack(pady=5)  # add padding

    genre_dropdown = ttk.Combobox(add_book_window, values=get_genre_options(), state="readonly")  # dropdown for genre
    genre_dropdown.pack(pady=5)  # add padding

    genre_dropdown.current(0)  # set default value

    # rating label and dropdown
    rating_label = tk.Label(add_book_window, text="Rating (1-5):", bg = "lavender", fg = "black", font = ("Arial", 12))  # label for rating
    rating_label.pack(pady=5)  # add padding

    rating_dropdown = ttk.Combobox(add_book_window, values=get_rating_options(), state="readonly")  # dropdown for rating
    rating_dropdown.pack(pady=5)  # add padding

    rating_dropdown.current(0)  # set default value

    # status label and dropdown
    status_label = tk.Label(add_book_window, text="Status:", bg = "lavender", fg = "black", font = ("Arial", 12))  # label for status
    status_label.pack(pady=5)  # add padding

    status_dropdown = ttk.Combobox(add_book_window, values=get_status_options(), state="readonly")  # dropdown for status
    status_dropdown.pack(pady=5)  # add padding

    status_dropdown.current(0)  # set default value

    # create buttons
    add_book_button = tk.Button(add_book_window, text="Add Book", command=lambda: submit_book(title_entry, author_entry, genre_dropdown, rating_dropdown, status_dropdown), bg = "#8A2BE2", fg = "white", font = ("Arial", 12), width = 12, height = 2)  # button to add book
    add_book_button.pack(pady=10)  # add padding

    clear_button = tk.Button(add_book_window, text="Clear Fields", command=lambda: clear_fields(title_entry, author_entry, genre_dropdown, rating_dropdown, status_dropdown), bg = "#FFDBBB", fg = "black", font = ("Arial", 12), width = 12, height = 2)  # button to clear fields
    clear_button.pack(pady=10)  # add padding

    exit_button = tk.Button(add_book_window, text="Back to Main", command=add_book_window.destroy, bg = "grey", fg = "black", font = ("Arial", 12), width = 12, height = 2)  # button to exit program
    exit_button.pack(pady=10)  # add padding

    # run the window
    add_book_window.mainloop()  # run the window

# define function to submit book
def submit_book(title, author, genre, rating, status):
    """adds book to library.json"""
    # get values from input fields
    title = title.get()  # get title from entry field
    author = author.get()  # get author from entry field
    genre = genre.get()  # get genre from dropdown
    rating = rating.get()  # get rating from dropdown
    status = status.get()  # get status from dropdown

    # validate input
    if not title or not author or not genre or not rating or not status:
        show_message("Error", "All fields are required.")   # show error message if any field is empty
        return
    
    # load existing library data
    library_data = load_library()  # load library data for JSON file
    #if library_data is None:
        #library_data = []
    #else:
        #library_data = json.loads(library_data)
    
    # create book entry
    book_entry = {
        "title": title,  # title of the book
        "author": author,  # author of the book
        "genre": genre,  # genre of the book
        "rating": rating,  # rating of the book
        "status": status  # status of the book
    }

    # append new book entry to library
    library_data.append(book_entry) 

    # save library data to JSON file
    if save_library(library_data):
        show_message("Success", "Book added successfully.")
        #clear_fields(title_entry, author_entry, genre_dropdown, rating_dropdown, status_dropdown)  # clear fields after submission
    else:
        show_message("Error", "Failed to add book. Please try again.")  # show error message