# final GUI project: Book Nook: view library window
# author: Brooke Nafziger
# created: 2025-05-10
# NO CODING ASSISTANCE was used in this program

# view library window

# import libraries: tkinter, json
# import custom modules: utils
# window title: "Library"
# scrolled listbox to display book entries
# button: "Back to Main" --> closes view library window and returns to main window
# functions:
# open_view_books_window() --> creates view library window
# display_books() --> reads library.json and displays book entries in listbox
# back_to_main() --> closes view library window and returns to main window

# import libraries
import tkinter as tk
from tkinter import messagebox, scrolledtext  # for message boxes and scrolled text area
import json

# import custom modules
from add_book import open_add_book_window  # function to open and add book window
from utils import load_library, save_library  # utility functions

# define function to display books in a scrolled text area
def display_books(library_window, library):
    """displays books in a scrolled text area"""
    # clear the text area
    library_window.text_area.delete(1.0, tk.END)  # delete all text from the text area
    
   # library_data = load_library()  # load library data for JSON file

     # check if library is empty
    if not library:
        library_window.text_area.insert(tk.END, "No books in the library.")  # insert message if no books
    return


# create view library window
def open_view_books_window():
    library_window = tk.Toplevel()
    library_window.title("Library")
    library_window.geometry("800x400")
    library_window.configure(bg="lightgrey")

    # create canvas and scrollbar
    canvas = tk.Canvas(library_window, bg="lightgrey")
    scrollbar = tk.Scrollbar(library_window, orient="vertical", command=canvas.yview)
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # frame inside canvas
    scrollable_frame = tk.Frame(canvas, bg="lightgrey")
    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")

    # resize scroll region dynamically
    scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

    # --- Use grid inside the scrollable frame ---
    headers = ["Title", "Author", "Genre", "Rating", "Status"]
    for col, text in enumerate(headers):
        tk.Label(scrollable_frame, text=text, bg="#FFDBBB", font=("Arial", 12, "bold"), borderwidth=1,
                 relief="solid", padx=5, pady=5).grid(row=0, column=col, sticky="nsew")     # header labels

    # load in library data
    library_data = load_library()
    if library_data:
        for row, book in enumerate(library_data, start=1):
            tk.Label(scrollable_frame, text=book.get("title", ""), bg="lightgrey").grid(row=row, column=0, padx=10, pady=2)
            tk.Label(scrollable_frame, text=book.get("author", ""), bg="lightgrey").grid(row=row, column=1, padx=10, pady=2)
            tk.Label(scrollable_frame, text=book.get("genre", ""), bg="lightgrey").grid(row=row, column=2, padx=10, pady=2)
            tk.Label(scrollable_frame, text=book.get("rating", ""), bg="lightgrey").grid(row=row, column=3, padx=10, pady=2)
            tk.Label(scrollable_frame, text=book.get("status", ""), bg="lightgrey").grid(row=row, column=4, padx=10, pady=2)
    else:
        tk.Label(scrollable_frame, text="No books found.", bg="lightgrey").grid(row=1, column=0, columnspan=5, pady=20)         # if no books are found

    # create button to go back to main window
    tk.Button(scrollable_frame, text="Back to Main", command=library_window.destroy, bg="black", fg="white")\
        .grid(row=999, column=0, columnspan=5, pady=10)
